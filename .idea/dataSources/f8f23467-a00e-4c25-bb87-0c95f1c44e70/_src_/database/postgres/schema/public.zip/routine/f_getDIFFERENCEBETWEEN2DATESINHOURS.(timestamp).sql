create function "f_getDIFFERENCEBETWEEN2DATESINHOURS"(date timestamp without time zone) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
tmp1 integer;
result integer;
BEGIN
--SELECT INTO tmp EXTRACT(EPOCH FROM AGE(NOW(), $1))/60;
select "f_getDIFFERENCEBETWEEN2DATESINMINUTES"($1) into tmp1; 
result  := tmp1/60;
RETURN result;
END;
$$;
