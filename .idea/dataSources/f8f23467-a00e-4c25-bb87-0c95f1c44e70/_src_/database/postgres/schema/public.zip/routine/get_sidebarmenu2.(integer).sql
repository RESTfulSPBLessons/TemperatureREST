create function get_sidebarmenu2(v1 integer) returns TABLE(id integer, elementid integer, note character varying)
LANGUAGE plpgsql
AS $$
BEGIN

   Select sidebarmenuitems.id, sidebarmenuitems.elementid, sidebarmenuitems.note
   From sidebarmenuitems 
   where sidebarmenuitems.user = v1;
   RETURN NEXT;
END;
$$;
