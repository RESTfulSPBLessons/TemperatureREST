create function onlyemailcheck(email character varying) returns boolean
LANGUAGE plpgsql
AS $$
DECLARE
tmp integer;
BEGIN
SELECT count(*) INTO tmp FROM users WHERE users.email = $1;

IF tmp>0 THEN
      RETURN TRUE;
   ELSE
      RETURN FALSE;
   END IF;
END;
$$;
