create function get_sidebarmenu3(v1 integer) returns TABLE(i integer, e character varying)
LANGUAGE SQL
AS $$
Select id, elementid From sidebarmenuitems where sidebarmenuitems.user = v1
$$;
