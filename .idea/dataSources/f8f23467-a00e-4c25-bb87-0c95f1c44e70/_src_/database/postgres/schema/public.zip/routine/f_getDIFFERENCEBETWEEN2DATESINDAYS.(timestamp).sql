create function "f_getDIFFERENCEBETWEEN2DATESINDAYS"(date timestamp without time zone) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
tmp1 integer;
result integer;
BEGIN
--SELECT INTO tmp EXTRACT(EPOCH FROM AGE(NOW(), $1))/60;
select "f_getDIFFERENCEBETWEEN2DATESINHOURS"($1) into tmp1; 
result  := tmp1/24;
RETURN result;
END;
$$;
