create function get_orderstatus_by_code(code integer) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
tmp integer;
row_data RECORD;
query_string text := '';
BEGIN



FOR row_data IN 
    EXECUTE format(' 
    SELECT id FROM order_status 
    WHERE order_status."Code" = $1') USING code      
LOOP 
IF row_data.id>0 THEN
	tmp = row_data.id;
    RETURN tmp;
    EXIT;
END IF;
END LOOP; 

IF tmp<1 THEN
      RETURN 0;
END IF;
END;
$$;
