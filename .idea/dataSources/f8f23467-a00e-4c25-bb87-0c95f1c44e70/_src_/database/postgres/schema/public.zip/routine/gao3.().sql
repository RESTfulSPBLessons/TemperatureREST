create function gao3() returns compfoo
LANGUAGE plpgsql
AS $$
DECLARE
  result compfoo;
BEGIN
  SELECT orders.id, orders.order_short_name INTO result.id, result.username FROM orders;
  return result ;
END
$$;
