create function "f_getDIFFERENCEBETWEEN2DATESINMINUTES"(date timestamp without time zone) returns integer
LANGUAGE plpgsql
AS $$
DECLARE
tmp integer;
BEGIN
SELECT INTO tmp EXTRACT(EPOCH FROM AGE(NOW(), $1))/60;
      RETURN tmp;
END;
$$;
