create function update_user_created_date() returns trigger
LANGUAGE plpgsql
AS $$
BEGIN
 IF TG_OP='INSERT' THEN
       NEW.datecreated = now();
    END IF;
 RETURN NEW;
 END;
$$;
