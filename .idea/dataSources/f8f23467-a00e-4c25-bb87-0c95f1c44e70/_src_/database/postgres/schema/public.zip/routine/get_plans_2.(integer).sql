create function get_plans_2(id integer DEFAULT 1) returns TABLE(id integer, plan character varying, cost integer, parent_subtype_id integer, json json)
LANGUAGE SQL
AS $$
Select  pl.id, pl.plan_name, pl.cost, pl.parent_subtype_id, (Select * From get_options_for_plan(pl.id)) as r From plans pl where pl.parent_subtype_id=$1;
$$;
