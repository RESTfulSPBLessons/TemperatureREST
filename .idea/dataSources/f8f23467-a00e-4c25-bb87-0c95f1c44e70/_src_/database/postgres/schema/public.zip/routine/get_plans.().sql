create function get_plans() returns TABLE(plan character varying, json json)
LANGUAGE SQL
AS $$
Select  pl.plan_name, (SELECT json_agg(r.*) as tags
FROM (Select p.id, p.optionname From options p INNER JOIN plans pu on p.plan_id = pu.id) AS r) as Rr 
 From plans pl INNER JOIN options op on pl.id = op.plan_id group by pl.plan_name;
 
 
 
 /* 
 
 , (SELECT json_agg(r.*) as tags
FROM (select options.id, options.optionname, options.plan_id from options, plans where options.plan_id = plans.id) AS r) as Rr
 
  */
$$;
