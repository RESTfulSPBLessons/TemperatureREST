create function update_order_status_code(code integer, id integer) returns void
LANGUAGE plpgsql
AS $$
DECLARE
tmp integer;
row_data RECORD;
query_string text := '';
BEGIN

EXECUTE format('UPDATE order_status SET "Code" = null WHERE "Code"=$1') USING code;
EXECUTE format('UPDATE order_status SET "Code" = $1 WHERE order_status.id=$2') USING code, id;

END;
$$;
