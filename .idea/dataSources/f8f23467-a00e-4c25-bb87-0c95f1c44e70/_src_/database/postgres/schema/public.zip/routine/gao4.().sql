create function gao4() returns SETOF json
LANGUAGE SQL
AS $$
select row_to_json(dd) from (Select orders.id, (select row_to_json(t) from (select clients.id, clients.name from clients where clients.id = orders.client) t) as Rr,
   orders.order_short_name, orders.order_info, orders.order_cost, orders.order_create_date, orders.order_deadline, orders.order_type, 
   (select row_to_json(s) from (select order_status.id, order_status.status from order_status where order_status.id = orders.order_status) s) as orderstatus 
   From orders 
   where orders.user_id = 2) as dd;
$$;
