CREATE TRIGGER WS_COMMON_LOGS_TRIG
BEFORE INSERT
  ON WS_COMMON_LOGS
FOR EACH ROW
  begin
  if :new.id is null then
    select WS_COMMON_LOG_SEQ.NEXTVAL into :new.id from dual;
  end if;
  if :new.admdate is null then
    select sysdate into :new.admdate from dual;
  end if;
end;
/
